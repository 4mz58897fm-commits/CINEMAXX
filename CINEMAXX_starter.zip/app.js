const API_BASE = "https://api.themoviedb.org/3";
const IMG = "https://image.tmdb.org/t/p/";
const $ = (id) => document.getElementById(id);
let page = "home", searchMode = false, query = "", pageNumber = 1, totalPages = 1, currentItems = [], selectedItem = null;
let token = localStorage.getItem("cinemaxx_tmdb_token") || "";
let watchlist = JSON.parse(localStorage.getItem("cinemaxx_watchlist") || "[]");
const fallbackItems = [
 {id:1,title:"Connect TMDB to begin",overview:"Add your TMDB API Read Access Token in Settings to load real movies and shows. This sample card is only a setup guide, not a movie listing.",poster_path:null,backdrop_path:null,release_date:"",vote_average:null,media_type:"movie",isSetup:true},
];
function mediaType(item){return item.media_type || (item.name ? "tv" : "movie")}
function titleOf(item){return item.title || item.name || "Untitled"}
function yearOf(item){const d=item.release_date||item.first_air_date;return d?d.slice(0,4):"Release date unknown"}
function isSaved(item){return watchlist.some(x=>x.id===item.id&&mediaType(x)===mediaType(item))}
function saveList(){localStorage.setItem("cinemaxx_watchlist",JSON.stringify(watchlist))}
async function api(path){
 if(!token) throw new Error("Add your TMDB API Read Access Token in Settings to load the real catalog.");
 const res=await fetch(API_BASE+path,{headers:{Authorization:`Bearer ${token}`,Accept:"application/json"}});
 if(!res.ok) throw new Error(res.status===401?"TMDB token was rejected. Check the token in Settings.":`Catalog request failed (${res.status}).`);
 return res.json();
}
function showStatus(text=""){ $("search-status").textContent=text }
function imageUrl(path,size="w500"){return path?IMG+size+path:""}
function card(item){
 const type=mediaType(item), title=titleOf(item), rating=typeof item.vote_average==="number"&&item.vote_average>0?item.vote_average.toFixed(1):"—";
 const el=document.createElement("article");el.className="movie-card";
 const poster=document.createElement("div");poster.className="poster-wrap";
 if(item.poster_path){const img=document.createElement("img");img.loading="lazy";img.alt=`${title} poster`;img.src=imageUrl(item.poster_path);img.onerror=()=>{img.remove();poster.innerHTML='<div class="poster-placeholder">CINEMAXX</div>'};poster.appendChild(img)}else poster.innerHTML=`<div class="poster-placeholder">${item.isSetup?"ADD YOUR API TOKEN":"NO ARTWORK"}</div>`;
 if(!item.isSetup){poster.insertAdjacentHTML("beforeend",`<span class="card-rating">★ ${rating}</span><span class="card-type">${type==="tv"?"SERIES":"MOVIE"}</span>`)}
 const info=document.createElement("div");info.className="card-info";
 info.innerHTML=`<p class="card-title" title="${escapeHtml(title)}">${escapeHtml(title)}</p><div class="card-meta"><span>${escapeHtml(yearOf(item))}</span><span>${item.isSetup?"SETUP":rating==="—"?"":`★ ${rating}`}</span></div>`;
 if(!item.isSetup){const actions=document.createElement("div");actions.className="card-actions";actions.innerHTML=`<button data-action="details">Details</button><button data-action="save">${isSaved(item)?"✓ Saved":"+ My List"}</button>`;actions.querySelector('[data-action="details"]').onclick=()=>openDetails(item);actions.querySelector('[data-action="save"]').onclick=(e)=>{e.stopPropagation();toggleSaved(item);actions.querySelector('[data-action="save"]').textContent=isSaved(item)?"✓ Saved":"+ My List"};el.onclick=()=>openDetails(item);el.append(poster,info,actions)}else{el.append(poster,info);el.onclick=openSettings}
 return el;
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(items){
 currentItems=items;const grid=$("movie-grid");grid.innerHTML="";
 if(!items.length){grid.innerHTML='<div class="empty-state"><h3>No titles found</h3><p>Try another search or filter.</p></div>'}
 else items.forEach(item=>grid.appendChild(card(item)));
 $("result-count").textContent=items.length?`${items.length} titles`:"";
 $("load-more").classList.toggle("hidden",pageNumber>=totalPages||!items.length||searchMode&&query.trim()==="");
}
function updateSetupNotice(){ $("setup-notice").classList.toggle("hidden",Boolean(token)); }
async function loadCatalog(append=false){
 pageNumber=append?pageNumber+1:1;
 updateSetupNotice();
 if(page==="watchlist"){ $("page-heading").textContent="My Watchlist";showStatus("");render(watchlist);$("load-more").classList.add("hidden");return}
 if(!token){ $("page-heading").textContent=searchMode?"Search results":page==="tv"?"Popular TV shows":page==="movies"?"Popular movies":"Trending now";showStatus("Connect TMDB in Settings to load real catalog data.");render(fallbackItems);$("load-more").classList.add("hidden");return}
 try{
  showStatus("Loading real movie and TV data…");
  let path;
  if(searchMode&&query.trim()) path=`/search/multi?query=${encodeURIComponent(query.trim())}&include_adult=false&page=${pageNumber}`;
  else if(page==="movies") path=`/movie/popular?page=${pageNumber}`;
  else if(page==="tv") path=`/tv/popular?page=${pageNumber}`;
  else if($("sort-select").value==="rating") path=`/movie/top_rated?page=${pageNumber}`;
  else if($("sort-select").value==="newest") path=`/movie/now_playing?page=${pageNumber}`;
  else path=`/trending/all/week?page=${pageNumber}`;
  const data=await api(path);
  let items=(data.results||[]).filter(x=>x.media_type!=="person"&&x.poster_path);
  if(searchMode&&query.trim()) items=items.filter(x=>x.media_type==="movie"||x.media_type==="tv");
  totalPages=Math.min(data.total_pages||1,500);
  if(append) render(currentItems.filter(x=>!x.isSetup).concat(items));else render(items);
  showStatus(items.length?"":"No matching titles found.");
  if(!searchMode&&!append&&page==="home"&&items.length) setHero(items[0]);
 }catch(err){showStatus(err.message);render([]);$("load-more").classList.add("hidden")}
}
function setHero(item){
 selectedItem=item;
 $("hero-title").innerHTML=`${escapeHtml(titleOf(item))}<br><span>on CINEMAXX</span>`;
 $("hero-description").textContent=item.overview||"Explore this title and discover more.";
 $("hero-meta").textContent=`${yearOf(item)}  •  ${mediaType(item)==="tv"?"TV SERIES":"MOVIE"}  •  ${item.vote_average?`★ ${item.vote_average.toFixed(1)}`:"Rating unavailable"}`;
 const bg=item.backdrop_path?`linear-gradient(90deg,#09090df7 0%,#09090dcf 42%,#09090d40 100%),linear-gradient(0deg,#09090d,transparent 40%),url("${imageUrl(item.backdrop_path,"original")}")`:"radial-gradient(ellipse at 70% 40%,#7c142d88,transparent 42%),linear-gradient(110deg,#1c0c16,#15121c 48%,#08090d)";
 $("hero").style.backgroundImage=bg;$("hero").style.backgroundSize="cover";$("hero").style.backgroundPosition="center";
 $("hero-details").onclick=()=>openDetails(item);
 $("hero-trailer").onclick=()=>openDetails(item,true);
}
function openDetails(item, trailer=false){
 selectedItem=item;
 const type=mediaType(item), title=titleOf(item);
 const backdrop=item.backdrop_path?imageUrl(item.backdrop_path,"w1280"):"";
 $("detail-content").innerHTML=`<div class="detail-backdrop" style="background-image:linear-gradient(0deg,#111117,transparent 90%),linear-gradient(90deg,#11111788,transparent),url('${backdrop}')"><h2>${escapeHtml(title)}</h2></div><div class="detail-body"><p class="detail-meta">${escapeHtml(yearOf(item))} · ${type==="tv"?"TV SERIES":"MOVIE"} · ${item.vote_average?`★ ${item.vote_average.toFixed(1)}`:"Rating unavailable"}</p><p class="detail-overview">${escapeHtml(item.overview||"No synopsis is available for this title.")}</p><div class="detail-actions"><button class="primary-button" id="detail-trailer">▷ Watch trailer</button><button class="secondary-button" id="detail-save">${isSaved(item)?"✓ In My List":"＋ Add to My List"}</button></div><p class="muted" id="playback-message">Full-length playback is available only when an authorized video source is connected. Catalog metadata and posters do not provide the movie itself.</p><div id="trailer-area"></div></div>`;
 $("detail-save").onclick=()=>{toggleSaved(item);$("detail-save").textContent=isSaved(item)?"✓ In My List":"＋ Add to My List";};
 $("detail-trailer").onclick=()=>loadTrailer(item);
 $("detail-dialog").showModal();
 if(trailer) loadTrailer(item);
}
async function loadTrailer(item){
 const area=$("trailer-area");if(!area)return;
 if(!token){area.innerHTML='<p class="muted">Connect TMDB in Settings to find official trailer metadata.</p>';return}
 try{
  const type=mediaType(item),data=await api(`/${type}/${item.id}/videos?language=en-US`);
  const v=(data.results||[]).find(x=>x.site==="YouTube"&&x.type==="Trailer"&&x.key)|| (data.results||[]).find(x=>x.site==="YouTube"&&x.key);
  if(!v){area.innerHTML='<p class="muted">No trailer was found in the catalog.</p>';return}
  area.innerHTML=`<h3>Trailer: ${escapeHtml(v.name||titleOf(item))}</h3><div style="aspect-ratio:16/9;overflow:hidden;border-radius:12px;background:#000"><iframe title="Movie trailer" width="100%" height="100%" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.key)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></div>`;
 }catch(e){area.innerHTML=`<p class="muted">${escapeHtml(e.message)}</p>`}
}
function toggleSaved(item){
 const i=watchlist.findIndex(x=>x.id===item.id&&mediaType(x)===mediaType(item));
 if(i>=0)watchlist.splice(i,1);else watchlist.push({...item});
 saveList();if(page==="watchlist")loadCatalog();
}
function openSettings(){ $("tmdb-token").value=token;$("settings-dialog").showModal()}
function goPage(next){
 page=next;searchMode=false;query="";$("search-input").value="";$("search-panel").classList.add("hidden");
 document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===next));
 $("page-heading").textContent=next==="watchlist"?"My Watchlist":next==="movies"?"Popular movies":next==="tv"?"Popular TV shows":"Trending now";
 loadCatalog();
 window.scrollTo({top:document.querySelector(".content-wrap").offsetTop-70,behavior:"smooth"});
}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>goPage(b.dataset.page)));
$("search-toggle").onclick=()=>{$("search-panel").classList.toggle("hidden");if(!$("search-panel").classList.contains("hidden"))$("search-input").focus()};
let searchTimer;
$("search-input").addEventListener("input",e=>{query=e.target.value;searchMode=Boolean(query.trim());page="home";clearTimeout(searchTimer);searchTimer=setTimeout(()=>{pageNumber=1;loadCatalog()},300)});
$("search-clear").onclick=()=>{$("search-input").value="";query="";searchMode=false;loadCatalog()};
$("load-more").onclick=()=>loadCatalog(true);
$("sort-select").onchange=()=>loadCatalog();
$("open-settings").onclick=openSettings;$("footer-settings").onclick=openSettings;
$("save-token").onclick=()=>{token=$("tmdb-token").value.trim();if(token)localStorage.setItem("cinemaxx_tmdb_token",token);else localStorage.removeItem("cinemaxx_tmdb_token");$("settings-dialog").close();loadCatalog()};
$("remove-token").onclick=()=>{token="";localStorage.removeItem("cinemaxx_tmdb_token");$("tmdb-token").value="";$("settings-dialog").close();loadCatalog()};
$("profile-button").onclick=()=>$("profile-dialog").showModal();
$("profile-watchlist").onclick=()=>{$("profile-dialog").close();goPage("watchlist")};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$(b.dataset.close).close());
$("hero-details").onclick=openSettings;$("hero-trailer").onclick=openSettings;
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("/sw.js").catch(()=>{});
updateSetupNotice();loadCatalog();