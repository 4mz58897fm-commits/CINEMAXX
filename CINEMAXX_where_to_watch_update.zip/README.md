# CINEMAXX starter

A responsive movie-discovery website with real TMDB catalog integration, watchlist storage on the current device, trailer embeds, PWA setup, and a Capacitor Android project configuration.

## Run locally

1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open the local URL shown in the terminal.

## Connect real movie data

1. Create an account at TMDB and request API access: https://www.themoviedb.org/settings/api
2. In CINEMAXX, open **Settings & API** and paste your TMDB API Read Access Token.
3. The app will request real movie and TV metadata, posters, ratings, and trailer metadata.

Important: TMDB provides catalog metadata and artwork, not full-length movies. Full-length playback requires a separately configured authorized streaming or video-hosting provider. This starter intentionally does not fake movie playback.

For production, proxy TMDB requests through a secure backend instead of storing a token in browser local storage. Review current TMDB attribution and licensing requirements.

## Install as a PWA

Deploy the website to HTTPS. On iPhone, open it in Safari, tap Share, then **Add to Home Screen**. On Android, use the browser's **Install app** or **Add to Home screen** option.

The included service worker caches the app shell for faster repeat loading. It does not download movies for offline playback.

## Build Android APK with Capacitor

Use a current Node.js LTS installation and Android Studio.

1. Run `npm install`
2. Build/host the web files as required for your deployment.
3. Confirm `webDir` in `capacitor.config.json` points at the built web output folder. For this simple static starter, the config currently points at the project root.
4. Run `npx cap add android`
5. Run `npx cap sync android`
6. Run `npx cap open android`
7. In Android Studio, wait for Gradle sync.
8. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a test APK.
9. For release distribution, configure signing and use **Build > Generate Signed Bundle / APK**.

Do not commit signing passwords or private keys. Test video playback and authentication on a real Android device before release.

## Current limitations

- Watchlist is stored locally on the device, not synced between accounts/devices.
- No Supabase account system is wired in yet.
- No full-length video provider is connected.
- TMDB token is stored in local browser storage for convenience; this is suitable only for a local prototype, not a secure public deployment.
- iOS native distribution requires a separate iOS build/signing process; Android APK files do not install on iPhone.
